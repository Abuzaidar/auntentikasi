import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import router from "./routes/UserRoute.js";

dotenv.config();

const app = express();

mongoose.connect('mongodb://localhost:27017/fullstack_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', (error) => console.log(error));
db.once('open', () => console.log('database connected..'));

app.use(router)

app.use(cors({
  credentials: true,
  origin: 'http://localhost:3000'
}));

app.use(express.json());

app.listen(process.env.APP_PORT, () => {
  console.log('Server up and Running..')
});