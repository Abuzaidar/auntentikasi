import express from "express";
import {
  getUsers,
  getUsersbyId,
  saveUsers,
  updateUsers,
  deleteUsers
} from "../controllers/UseController.js";

const router = express.Router();

router.get('/user', getUsers);
router.get('/user/:id', getUsersbyId)
router.post('/user', saveUsers);
router.patch('/user/:id', updateUsers);
router.delete('/user/:id', deleteUsers);


export default router;
