import User from "../models/UserModels.js";


export const getUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ messege: error.messege });
  }
}

export const getUsersbyId = async (req, res) => {
  try {
    const getuserbyid = await User.findById(req.params.id);
    res.json(getuserbyid);
  } catch (error) {
    res.status(404).json({ messege: error.messege });
  }
}

export const saveUsers = async (req, res) => {
  const saveuser = new User(req, body)
  try {
    const saveusered = await saveuser.save();
    res.status(201).json(saveusered);
  } catch (error) {
    res.status(400).json({ messege: error.messege });
  }
}

export const updateUsers = async (req, res) => {
  const cekId = await User.findById(req.params.id);
  if (!cekId) return res.status(404).json({ messege: "Data tidak ditemukan.." });
  try {
    const updateuser = await User.updateOne({ _id: req.params.id }, { $set: req.body });
    res.status(200).json(updateuser);
  } catch (error) {
    res.status(400).json({ messege: error.messege });
  }
}

export const deleteUsers = async (req, res) => {
  const cekId = await User.findById(req.params.id);
  if (!cekId) return res.status(404).json({ messege: "Data tidak ditemukan.." });
  try {
    const deleteuser = await User.deleteOne({ _id: req.params.id });
    res.status(200).json(deleteuser);
  } catch (error) {
    res.status(400).json({ messege: error.messege });
  }
}
